(() => {
  let domContent = document.documentElement.outerHTML;
  return domContent;
})();